This is a guide on how to view your DxGy Promotions data.

Some data fields will have the data value “Not Available”. This means that there was no data present for that field.



Digital.ActionBenefit.1.csv
- The file contains the customer action(s) where the customer ended up getting benefits (dollar credits or similar).