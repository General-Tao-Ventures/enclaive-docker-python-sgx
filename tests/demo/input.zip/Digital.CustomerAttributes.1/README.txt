This is a guide on how to view your regional attribute data.

Some data fields will have the data value “Not Available”. This means that there was no data present for that field.



Digital.CustomerAttributes.1.csv
- This file has data related to customer's regional attributes